// scroll function
function scrollToID(id, speed){
	var offSet = 0;
	var targetOffset = $(id).offset().top - offSet;
	
	$('html,body').animate({scrollTop:targetOffset}, speed);
	
	var mainNav = $('#nav-toggle');
	if (mainNav.is(":visible")) {
		mainNav.slideUp();
	}
}
if (typeof console === "undefined") {
    console = {
        log: function() { }
    };
}

$(document).ready(function() {

	$(document).on('click',function(event){
		if(!($(event.target).is($('.toggle-nav')) || $(event.target).is($('.toggle-nav>span')) ) && $('#nav-toggle').is(':visible'))
			$('#nav-toggle').slideUp();
	});
	
	// navigation click actions	
	$('.scroll-link').on('click', function(event){
		event.preventDefault();
		var sectionID = $(this).attr("href");
		scrollToID(sectionID, 650);
		
		$('.scroll-link').removeClass('active');
		$(this).addClass('active');
		
	});
	
	$('.read-more-button').on('click', function(event){
		event.preventDefault();
		var sectionID = $(this).attr("href");
		scrollToID(sectionID, 650);		
	});
	
	
	// scroll to top action
	$('.scroll-top').on('click', function(event) {
		event.preventDefault();
		$('html, body').animate({scrollTop:0}, 'slow'); 		
	});
	// mobile nav toggle
	$('.toggle-nav').on('click', function (event) {
		event.preventDefault();
		$('#nav-toggle').slideToggle().removeClass('hidden');/* toggleClass("open"); */ 
	});

	
		
	
	/*onscroll function*/
	var flag=0;	/*to restrict changes everytime*/
	$(window).scroll(function(){			
		var sVal=$(window).scrollTop();			
		if(sVal>100 && flag==0)
		{
			$('.header-wrapper').animate({padding:'10px'},750);
			flag=1;
		}
		else if(sVal<100 && flag==1)
		{
			$('.header-wrapper').animate({padding:'60px 10px 30px'},750);
			flag=0;
		}	
	});
	
	
});
